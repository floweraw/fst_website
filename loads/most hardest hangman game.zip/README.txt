password is brotherhood ,
this game is hard 