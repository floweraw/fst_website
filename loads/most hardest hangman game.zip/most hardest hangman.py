a="1"
    #to access file
password="brotherhood"
bbbb=input("enter password:")
while a == "1":
    a="2"
    #THIS FILE USES OS MODULE JUST TO SHUTDOWN YOUR COMPUTER
    #THIS FILE USES RANDOM MODULE TO PICK A WORD FROM VAST OCEAN OF WORD LIST
    #THIS FILE USES CSV MODULE TO WRITE YOUR TALENT INTO A CSV FILE
    #THIS FILE USES MYSQL.CONNECTOR TO WRITE YOUR TALENT INTO A DATABASE

    #NOTE THIS FILE CREATES CSV FILE NAME CALLED "scorecard" AND A DATABASE CALLED "scorefile"

    import os
    import random
    # words
    words=("apple", "banana", "carrot", "dog", "elephant", "flower", "guitar", "house", "island", "jacket",
    "kite", "lemon", "mountain", "notebook", "orange", "pencil", "quartz", "rainbow", "sun", "tree",
    "umbrella", "violin", "waterfall", "xylophone", "yarn", "zebra", "astronomy", "butterfly", "candle", "diamond",
    "eagle", "fireworks", "globe", "hat", "illusion", "juice", "kangaroo", "lamp", "moon", "necklace",
    "oasis", "pear", "queen", "rocket", "star", "turtle", "unicorn", "vase", "whale", "xylophone",
    "yo-yo", "zeppelin", "airplane", "ball", "cloud", "drum", "earth", "fire", "guitar", "heart",
    "ice cream", "jungle", "key", "ladder", "map", "noodle", "ocean", "penguin", "quilt", "robot",
    "sand", "tiger", "umbrella", "van", "wagon", "xylophone", "yogurt", "zipper", "apple", "book",
    "computer", "desk", "elephant", "frog", "giraffe", "house", "igloo", "jungle", "kite", "lion",
    "mouse", "nose", "ocean", "puzzle", "quilt", "rainbow", "sun", "tree", "umbrella", "volcano",
    "water", "xylophone", "yarn", "zeppelin"
    )


    #checking
    if bbbb==password:

        #collection info to write in file
        name = input("What is your name? ")
        print("Hello, " + name + ", Time to play hangman!")

        a = random.randint(0, len(words) - 1)

        word = words[a]
        l = len(word)
        turns = 10
        wd = "_" * l
        wdl=[]

        #converting your word into list
        for i in range(l):
            wdl.append(word[i])


        #Chcking when you need to leave
        while turns > 0:
            print("You have", turns, "turns")
            print(wd)

            #convering input word into list
            tmp=[]
            guess = input("Guess a letter: ")
            for i in range(len(guess)):
                tmp.append(guess[i])

            #removing problem of insuffient or excess range    
            if len(tmp)>len(wdl):
                xx=len(wdl)
                
            if len(wdl)>len(tmp):
                xx=len(tmp)
                
            if len(wdl)==len(tmp):
                xx=len(tmp)

            #checking how accurate your input is    
            for i in range(xx):
                if tmp[i] is wdl[i]:
                    wd=wd[:i]+tmp[i]+wd[i+1:]
            print(wd)
        
            #horray you won 
            if wd == word:
                print("Congratulations! You guessed the word:", word)
                break

            #to reduce the tuns so that you wond guess till eternity
            turns -= 1

        #to save you from reaching enternity in just one try 
        if turns == 0:
            print("Sorry, you ran out of turns. The word was:", word)
        scr=turns*10
        print(scr ," is you score")


        #wring your score into a score card
        import csv

        ## Data to be written to the CSV file
        data = [[name], [scr]]

        ## Specify the file name
        file_name = "scorecard.csv"

        ## Open the CSV file in 'a' (append) mode so that it wont rewrite the old data
        with open(file_name, 'a', newline='') as file:
            # Create a CSV writer object
            writer = csv.writer(file)
            
            # Write data to the CSV file
            writer.writerows(data)

        print(f"CSV file ",file_name ,"created successfully.")

        
    ##ULTRA FLEX
    else:
        print(" assasins are on the way you better run away")

    while True:
        a=input("enter 1 for replay \nenter 2 to quit\n")
        if a in ("1","2"):
            break
        else:
            print("Invalid input.")
