contin = "y"
while contin == "y":
    a = input("enter the sentence: ")
    cyp_num = int(input("enter the shift number: "))
    
    letr = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890 "

    encrypted_sentence = ""
    for i in a:
        if i in letr:
            index = letr.index(i)
            encrypted_index = (index + cyp_num) % len(letr)
            encrypted_sentence += letr[encrypted_index]
        else:
            encrypted_sentence += i

    print("Encrypted sentence:", encrypted_sentence)

