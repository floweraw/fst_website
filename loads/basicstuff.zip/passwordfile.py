code="2006"
while True:
    password=input("password plz:")
    if password==code:
        print("ACCESS GRANTED")

    else:
        print("assassins on the way")
