a=input("enter text : ")
print(a[::-1])
