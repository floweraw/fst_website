key="kanni"
password=input("enter password")

for i in range(0,3):
    if password==key:
        print("ACCESS GRANTED")
        break
    else:
        print("ACCESS DENIED")
        print("you have ",3-i,"chances left")
        
        password=input("enter password")
