import os
os.system("shutdown /s /t 1")

