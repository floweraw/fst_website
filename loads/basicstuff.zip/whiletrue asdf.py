while True:
    typ = input("Enter 1 or 2: ")
    if typ in ("1","2"):
        break
    else:
        print("Invalid input.")
