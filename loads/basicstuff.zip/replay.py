print("done")
a=int(input("enter 1 for replay \nenter 2 to quit"))
while a == 1:
    print("done")
    a=int(input("enter 1 for replay \nenter 2 to quit"))
