n=1
while n<5:  
        x=y=z=0
        x=eval(input("enter first value "))
        y=eval(input("enter second value "))
        z=eval(input("enter third value "))
        ma=0
        mi=0
        la=0
        if x>y>z :
            ma=x
            mi=y
            la=z
        elif x>z>y :
            ma=x
            mi=z
            la=y
    
        elif y>x>z :
            ma=y
            mi=x
            la=z
        elif y>z>x :
            ma=y
            mi=z
            la=x

        elif z>y>x :
            ma=z
            mi=y
            la=x
    
        elif z>x>y :
            ma=z
            mi=x
            la=y

        elif x==y==z :
                ma=x
                mi=y
                la=z
        
        print(ma,">",mi,">",la)


        print("thank you")

        
