import pyautogui #control mouse , like hand
import time #to not get caught
import win32api #something i dont know
import win32con #something i dont know
#############
#Mouse position: x1,y
#Mouse position: x2,y
#Mouse position: x3,y
#Mouse position: x4,y
#############
def click(x,y):
    win32api.SetCursorPos((x,y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,0,0)
    time.sleep(0.009)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,0,0)

while True:    
    if pyautogui.pixel(x1,y) == (0, 0, 0):
        click(x1,y)
    if pyautogui.pixel(x2,y) == (0, 0, 0):
        click(x2,y)
    if pyautogui.pixel(x3,y) == (0, 0, 0):
        click(x3,y)
    if pyautogui.pixel(x4,y) == (0, 0, 0):
        click(x4,y)
