import pyautogui
print("READ THIS BEFORE YOU PROCEED\n\nplace your cursor on first click point and press y\nnext on second point and so on\npress n when done\n\n")

n="y"
while n=="y":
    n=input("press y :")
    # Get the current position of the mouse cursor
    x, y = pyautogui.position()
    # Print the coordinates
    print("Mouse position:", x, y)
    